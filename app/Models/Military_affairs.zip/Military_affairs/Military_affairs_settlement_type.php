<?php

namespace App\Models\Military_affairs;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Military_affairs_settlement_type extends Model
{
    use HasFactory;
    protected $table = 'military_affairs_settlement_type';
    protected $guarded = [];

}
