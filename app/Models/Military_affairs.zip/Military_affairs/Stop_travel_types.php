<?php

namespace App\Models\Military_affairs;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Stop_travel_types extends Model
{
    use HasFactory;
    protected $guarded=[];
    protected $table ='military_affairs_stop_travel_type';

}
