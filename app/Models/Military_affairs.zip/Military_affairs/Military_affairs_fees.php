<?php

namespace App\Models\Military_affairs;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Military_affairs_fees extends Model
{
    use HasFactory;
    protected $guarded = [];
}
